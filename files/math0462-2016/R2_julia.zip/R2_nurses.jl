timesteps = 12;
required = [15, 14, 14, 17, 22, 20, 10, 20, 18, 15, 20, 20];
max_available = 55; 
;