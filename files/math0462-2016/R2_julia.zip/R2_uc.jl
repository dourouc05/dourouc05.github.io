n_machines = 3; 
time_steps = 12; 

fixed_costs = [5, 10, 1000];
variable_costs = [800, 700, 20];
max_power = [500, 700, 1500]; 
startup_costs = [10, 5, 850]; 
demands = [1500, 1200, 1800, 2000, 2200, 1750, 1600, 1500, 1200, 1500, 1600, 1800]; 
;