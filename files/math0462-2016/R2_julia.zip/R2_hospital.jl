n_hospitals = 3; 
n_demands = 6; 

fixed_costs = [500, 800, 1800]; 
variable_costs = [[1, 20, 10, 5, 50, 9]'; [18, 80, 11, 4, 40, 2]'; [20, 25, 30, 1, 35, 10]']; 
demands = [24, 12, 8, 96, 1, 48]; 
;