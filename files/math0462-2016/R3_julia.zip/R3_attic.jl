values = [[2., 5., 3.] [10., 0.1, 2.] [1., 24., 1.] [2., 10., 4.] [8., 14., .1] [12., 1.1, 4.] [8., 4., 1.] [8., 2., 9.] [4., 1.4, 1.5]]; # values[object, criterion]
n_objects = size(values, 2)
n_criteria = size(values, 1)
;